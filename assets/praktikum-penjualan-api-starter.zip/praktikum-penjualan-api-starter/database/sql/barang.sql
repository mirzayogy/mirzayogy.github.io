CREATE TABLE `barang` (
`id` INT NOT NULL AUTO_INCREMENT ,
`idjenisbarang` INT NOT NULL ,
`namabarang` VARCHAR(200) NOT NULL ,
`harga` DOUBLE NOT NULL,
PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `barang` (`id`, `idjenisbarang`, `namabarang`, `harga`) VALUES 
(NULL, '1', 'Celana Kargo', '300000'), 
(NULL, '1', 'Kemeja Pantai', '250000'),
(NULL, '2', 'Blouse Putih', '270000'), 
(NULL, '2', 'Rok Panjang', '350000') 