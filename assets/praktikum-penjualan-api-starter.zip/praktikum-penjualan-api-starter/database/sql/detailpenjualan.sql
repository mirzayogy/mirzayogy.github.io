CREATE TABLE `detailpenjualan` (
`id` INT NOT NULL AUTO_INCREMENT ,
`idpenjualan` INT NOT NULL ,
`idbarang` INT NOT NULL ,
`hargajual` DOUBLE NOT NULL,
`jumlah` INT NOT NULL,
PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `detailpenjualan` (`id`, `idpenjualan`, `idbarang`, `hargajual`, `jumlah`) VALUES 
(NULL, '1', '1', '300000', '2'), 
(NULL, '1', '4', '350000', '1'),
(NULL, '2', '4', '350000', '1'), 
(NULL, '3', '2', '250000', '1'),
(NULL, '3', '3', '270000', '2'), 
(NULL, '3', '4', '350000', '1'),
(NULL, '4', '1', '300000', '1'), 
(NULL, '5', '2', '250000', '1'), 
(NULL, '6', '1', '300000', '1'), 
(NULL, '6', '2', '250000', '1'), 
(NULL, '6', '3', '270000', '1')