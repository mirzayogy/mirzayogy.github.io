CREATE TABLE `jenisbarang` (
`id` INT NOT NULL AUTO_INCREMENT ,
`namajenisbarang` VARCHAR(200) NOT NULL ,
PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `jenisbarang` (`id`, `namajenisbarang`) VALUES 
(NULL, 'Pakaian pria'), 
(NULL, 'Pakaian wanita') 