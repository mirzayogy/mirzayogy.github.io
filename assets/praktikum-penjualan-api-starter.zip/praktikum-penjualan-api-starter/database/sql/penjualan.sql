CREATE TABLE `penjualan` (
`id` INT NOT NULL AUTO_INCREMENT ,
`tanggal` DATE NOT NULL ,
`idpengguna` INT NOT NULL ,
`status` ENUM('PENDING','SELESAI') NOT NULL,
PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `penjualan` (`id`, `tanggal`, `idpengguna`, `status`) VALUES
(1, '2020-12-01', 2, 'SELESAI'),
(2, '2020-12-01', 2, 'SELESAI'),
(3, '2021-01-02', 2, 'SELESAI'),
(4, '2021-01-03', 2, 'SELESAI'),
(5, '2021-02-01', 2, 'SELESAI'),
(6, '2021-02-03', 2, 'SELESAI');