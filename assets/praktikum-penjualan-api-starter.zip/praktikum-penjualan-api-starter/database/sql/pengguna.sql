CREATE TABLE `pengguna` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `username` varchar(25) NOT NULL,
  `password` varchar(200) NOT NULL,
  `namalengkap` varchar(200) NOT NULL,
  `isadmin` tinyint(1) NOT NULL,
PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `pengguna` (`id`, `username`, `password`, `namalengkap`, `isadmin`) VALUES
(NULL, 'admin', MD5('admin'), 'Nama Admin', '1'),
(NULL, 'user', MD5('user'), 'Nama User', '0')
