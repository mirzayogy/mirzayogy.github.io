<div class="row">
    <div class="col">
        <h3 class="fs-4 mb-3">404</h3>
    </div>
    <div class="col">
        <a href="javascript:history.back()" class="btn btn-primary float-end">
            <i class="fa fa-arrow-circle-left"></i>
            Kembali
        </a>
    </div>
</div>
<div class="row mt-3">
    <div class="col">
        <div class="alert alert-light" role="alert">
            Halaman tidak ditemukan
        </div>
    </div>
</div>