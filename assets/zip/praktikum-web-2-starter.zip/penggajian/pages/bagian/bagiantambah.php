<div class="row mb-3">
    <div class="col"></div>
</div>
<div class="row mb-3">
    <div class="col"></div>
</div>
<div class="row mb-3">
    <div class="col"></div>
</div>