<!-- based on: https://www.youtube.com/watch?v=CMwzLURK-rQ -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="plugins/bootstrap-5.2.3-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="plugins/fontawesome-free-6.4.2-web/css/all.min.css" />
    <link rel="stylesheet" href="plugins/datatables-1.13.7/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="assets/css/custom.css" />

    <script src="plugins/jquery-3.7.1/jquery.slim.min.js"></script>

    <!-- SweetAlert -->
    <script src="plugins/sweetalert2/sweetalert2.min.js"></script>
    <script>
        function pesanToast(pesan) {
            pesan = pesan ? pesan : "Berhasil simpan data"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: true,
                timer: 2000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: pesan
            });
        }

        function konfirmasi(title, text) {
            title = title ? title : 'Yakin ingin dihapus?'
            text = text ? text : "Data yang sudah dihapus tidak akan bisa dikembalikan"

            Swal.fire({
                title: title,
                text: text,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '?page=isianpelayanandelete&id=' + id + '&pelayanan_id=' + pelayanan_id;
                }
            })
        }
    </script>


    <title>BANGSUKRI - Aplikasi Barang Masuk dan Inventori</title>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom"><i class="fas fa-money-bill me-2"></i>BANGSUKRI</div>
            <div class="list-group list-group-flush my-3">
                <a href="index.php" class="list-group-item list-group-item-action bg-transparent abu-text active"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="#" class="list-group-item list-group-item-action bg-transparent abu-text fw-bold"><i class="fas fa-boxes me-2"></i>Barang Masuk</a>
                <a href="#" class="list-group-item list-group-item-action bg-transparent abu-text fw-bold"><i class="fas fa-check me-2"></i>Pengkodean</a>
                <a href="#" class="list-group-item list-group-item-action bg-transparent abu-text fw-bold"><i class="fas fa-building me-2"></i>Penempatan</a>
                <button class="list-group-item list-group-item-action bg-transparent abu-text fw-bold" data-bs-toggle="collapse" data-bs-target="#master-collapse" aria-expanded="true">
                    <i class="fas fa-list me-2"></i>Master
                </button>
                <div class="collapse" id="master-collapse">
                    <ul class="btn-toggle-nav list-unstyled ps-4">
                        <li><a href="#" class="link-dark rounded">Ruang</a></li>
                        <li><a href="#" class="link-dark rounded">Karyawan</a></li>
                        <li><a href="#" class="link-dark rounded">Pemasok</a></li>
                        <li><a href="#" class="link-dark rounded">Barang</a></li>
                    </ul>
                </div>
                <a href="#" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold"><i class="fas fa-power-off me-2"></i>Logout</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left second-text fs-4 me-3" id="menu-toggle"></i>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Fulan bin Fulan
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Ubah Password</a></li>
                                <li><a class="dropdown-item" href="#">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="container-fluid px-4">
                <div id="badges" class="row g-3 my-2">
                    <div class="col-md-6 col-lg-3">
                        <div class="p-3 hijo-bg shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2">101</h3>
                                <p class="fs-5 text-white">Ruang</p>
                            </div>
                            <i class="fas fa-building fs-1 text-white hijo-bg p-3"></i>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="p-3 secondary-bg shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2">102</h3>
                                <p class="fs-5 text-white">Karyawan</p>
                            </div>
                            <i class="fas fa-users fs-1 text-white secondary-bg p-3"></i>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="p-3 bg-primary shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2">103</h3>
                                <p class="fs-5 text-white">Pemasok</p>
                            </div>
                            <i class="fas fa-money-bill fs-1 text-white bg-primary p-3"></i>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="p-3 bg-danger shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2">104</h3>
                                <p class="fs-5 text-white">Barang</p>
                            </div>
                            <i class="fas fa-chart-line fs-1 text-white bg-danger p-3"></i>
                        </div>
                    </div>
                </div>
                <div id="atas" class="row">
                    <div class="col">
                        <div class="row">
                            <div class="col-md-6">
                                <h3>Ruang</h3>
                            </div>
                            <div class="col-md-6">
                                <a href="?page=ruangtambah" class="btn btn-success btn-sm float-end">
                                    <i class="fa fa-plus-circle"></i> Tambah
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tengah">
                    <script>
                        // konfirmasi()
                        // pesanToast()
                    </script>
                </div>
                <div id="bawah" class="row">
                    <div class="col">
                        <div class="card my-card">
                            <table class="table bg-white rounded shadow-sm  table-hover" id="example">
                                <thead>
                                    <tr>
                                        <th width="50">ID</th>
                                        <th>Ruang</th>
                                        <th width="200">Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="align-middle">
                                        <td>1</td>
                                        <td>Front Office</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-primary">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <a href="#" class="btn btn-sm btn-danger">
                                                <i class="fa fa-trash"></i> Hapus
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Marketing</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-primary">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <a href="#" class="btn btn-sm btn-danger">
                                                <i class="fa fa-trash"></i> Hapus
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Finance</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-primary">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <a href="#" class="btn btn-sm btn-danger">
                                                <i class="fa fa-trash"></i> Hapus
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-content-wrapper -->

    <!-- Datatables -->
    <script src="plugins/datatables-1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            new DataTable('#example');
        });
    </script>

    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>

    <!-- JavaScript Bundle with Popper -->
    <script src="plugins/bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function() {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>